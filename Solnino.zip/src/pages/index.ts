export {default as Home} from './home';
export {default as BetCreator} from './bet-creator'
export {default as AdminPanel} from './admin-panel'
export {default as Leaderboard} from './leaderboard'
export {default as PhonePage} from './phone-page'
export {default as ApplyPage} from './apply-panel'
export {default as MatchAdjust} from './match-adjust'