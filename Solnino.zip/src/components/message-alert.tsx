import { useState } from 'react';
import {Alert, IconButton,} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'

export default function MessageAlert(){
    const [openAlert, setOpenAlert] = useState(true)

    return <>
    </>
}